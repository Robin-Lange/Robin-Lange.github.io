# Robin Lange research resume for Overleaf

Upload this ZIP as a new Overleaf project. The main document is `main.tex` and compiles with pdfLaTeX. `style.tex` uses the standard xcolor, fontawesome5, and accsupp packages. Contact icons are decorative; the address, phone number, and LinkedIn URL remain selectable text.

The resume is two pages. Publication statuses and planned thesis comparisons are distinguished from completed results. The top-10% Descartes-Gymnasium class placement was supplied by Robin; the available public article confirms cohort size and grade distribution but not individual rank.
